/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */
package com.shell.command.crypto;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.shell.command.Command;
import com.shell.domain.common.constant.BaseConstants;
import com.shell.domain.common.constant.CommandConstants;
import com.shell.domain.common.constant.ErrorMessageConstants;
import com.shell.domain.common.enumeration.CommandOption;
import com.shell.domain.common.enumeration.MessageLevel;
import com.shell.domain.common.enumeration.TargetFileOption;
import com.shell.domain.common.message.Message;
import com.shell.domain.common.message.MessageCollection;
import com.shell.domain.common.message.MessageCollectionHelper;
import com.shell.domain.constant.BaseTestConstants;
import com.shell.domain.context.ShellContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()

public class DecryptCommandTest_UT extends AbstractBaseCryptoTestCommand
{
	@Autowired
	@Qualifier("decryptCommand")
	private Command decryptCommand;

	private static Log methIDrunTestDecryptCommandNullContextFAIL;
	private static Log methIDrunTestDecryptCommandPasswordTooShortFAIL;	
	private static Log methIDrunTestDecryptCommandIllegalBlockSizeFAIL;
	private static Log methIDrunTestDecryptCommandBasicFileMissingFileFAIL;
	private static Log methIDrunTestDecryptCommandInvalidOptionFAIL;
	private static Log methIDrunTestDecryptCommandBasicStringSUCCESS;

	private static Log methIDSetUpDefaultTargetFile;
	private static Log methIDSetUpBadTargetFile;

	private static Log methIDCheckOutputFileMatch;

	static
	{

		methIDrunTestDecryptCommandNullContextFAIL = LogFactory
				.getLog(DecryptCommandTest_UT.class.getName()
						+ ".runDecryptTestFAILContext()");		
		
		methIDrunTestDecryptCommandPasswordTooShortFAIL = LogFactory
				.getLog(DecryptCommandTest_UT.class.getName()
						+ ".runTestDecryptCommandPasswordTooShortFAIL()");

		methIDrunTestDecryptCommandIllegalBlockSizeFAIL = LogFactory
				.getLog(DecryptCommandTest_UT.class.getName()
						+ ".runTestDecryptCommandIllegalBlockSizeFAIL()");

		methIDrunTestDecryptCommandBasicFileMissingFileFAIL = LogFactory
				.getLog(DecryptCommandTest_UT.class.getName()
						+ ".runTestDecryptCommandBasicFileMissingFileFAIL()");
		
		methIDrunTestDecryptCommandInvalidOptionFAIL = LogFactory
				.getLog(DecryptCommandTest_UT.class.getName()
						+ ".runTestDecryptCommandInvalidOptionFAIL()");		
		
		methIDrunTestDecryptCommandBasicStringSUCCESS = LogFactory
				.getLog(DecryptCommandTest_UT.class.getName()
						+ ".runDecryptTestSUCCESS()");

		methIDSetUpDefaultTargetFile = LogFactory
				.getLog(DecryptCommandTest_UT.class.getName()
						+ ".setUpDefaultTargetFile()");

		methIDSetUpBadTargetFile = LogFactory
				.getLog(DecryptCommandTest_UT.class.getName()
						+ ".setUpBadTargetFile()");

		methIDCheckOutputFileMatch = LogFactory
				.getLog(DecryptCommandTest_UT.class.getName()
						+ ".checkOutputFileMatch()");

	}

	public void DecryptCommandTest_UT()
	{
		this.DecryptCommandTest_UT(true);
	}

	public void DecryptCommandTest_UT(boolean newValue)
	{
		this.setAssertON(newValue);
	}

	public void runAllTests()
	{

		this.runTestDecryptCommandNullContextFAIL();

		this.setUpDefaultTargetFile();
		this.runTestDecryptCommandBasicStringSUCCESS();
		this.checkOutputFileMatch();

		return;
	}

	@Before
	public void setUpDefaultTargetFile()
	{

		Log logger = methIDSetUpDefaultTargetFile;

		logger.debug(BaseConstants.BEGINS);

		this.writeTargetFile(TargetFileOption.TEST_FILE_CONTENTS_ENCRYPTED
				.toString());

		logger.debug(BaseConstants.ENDS);

		return;
	}

	@Test
	public void runTestDecryptCommandNullContextFAIL()
	{

		Log logger = methIDrunTestDecryptCommandNullContextFAIL;
		boolean returnValue = false;

		HashMap<String, Object> params = null;
		ShellContext context = null;

		// Set this to false, as the files should NOT match!
		this.setTargetFileMatches(false);

		// Set this as Empty...no file should have been generated.
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_EMPTY);

		logger.info("Decrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		context = new ShellContext();
		params = new HashMap<String, Object>();

		params.put(CommandConstants.COMMAND_OPTION, CommandOption.FILE_DECRYPT);

		params.put(BaseConstants.FILE_IN, BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);

		// PURPOSEFULLY DO NOT DO THIS!!! LEAVE NULL!!!
		// decryptCommand.setContext( context );

		returnValue = decryptCommand.execute();

		if (isAssertON())
		{
			Assert.assertFalse( returnValue );
		}

		return;
	}
	@Test
	public void runTestDecryptCommandPasswordTooShortFAIL()
	{
		Log logger = methIDrunTestDecryptCommandPasswordTooShortFAIL;
		boolean returnValue = false;

		HashMap params = null;
		ShellContext context = null;

		// Set this to true, as the files should match!
		this.setTargetFileMatches( true );

		// Set this as Empty to skip it..
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_EMPTY);
		
		logger.info("Decrypt Command Tests Begins...");
		logger.debug("Initializing.....");
		

		context = new ShellContext();

		params = new HashMap();

		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_DECRYPT );
		
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.BAD_PASSWORD_TOO_SHORT);

		context.setParams(params);

		decryptCommand.setContext(context);

		logger.info("Decrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		returnValue = decryptCommand.execute();

		if ( isAssertON() )
		{			
			Assert.assertFalse( returnValue );
		
			Assert.assertTrue(MessageCollectionHelper.verifyContextHasMessage(context,
					ErrorMessageConstants.PASSWORD_TOO_SHORT, MessageLevel.SEVERE) == 1);
		}
		
		logger.info("De-CryptCommand Tests Ends...");

		return;
		
	}	
	

	@Test
	public void runTestDecryptCommandBasicFileMissingFileFAIL()
	{
		Log logger = methIDrunTestDecryptCommandBasicFileMissingFileFAIL;
		boolean returnValue = false;
		
		HashMap params = null;
		ShellContext context = null;

		// Result should be NO File.
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_EMPTY);
		
		// Set this to true, as the files should NOT match!   
		this.setTargetFileMatches( false );

		logger.info("Decrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		context = new ShellContext();

		params = new HashMap();

		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_DECRYPT );
		
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_MISSING);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);

		decryptCommand.setContext(context);

		logger.debug("Running Decryption.....");

		returnValue = decryptCommand.execute();

		if ( isAssertON() )
		{			
			Assert.assertFalse(returnValue);
		}

		Assert.assertTrue(MessageCollectionHelper.verifyContextHasMessage(context,
				BaseTestConstants.EXCEPTION_FILE_NOT_FOUND, MessageLevel.SEVERE) == 1);
		
		logger.info("De-CryptCommand Tests Ends...");

		return;
	}	
	
	@Test
	public void runTestDecryptCommandIllegalBlockSizeFAIL()
	{

		Log logger = methIDrunTestDecryptCommandIllegalBlockSizeFAIL;
		boolean returnValue = false;

		HashMap params = null;
		ShellContext context = null;
		MessageCollection mc = null;
		Message msg = null;
		ArrayList<Message> msgZ = null;

		// Set this to false, as the files should NOT match!
		this.setTargetFileMatches(false);

		// Set this as Empty to skip it..
		this
				.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_ENCRYPTED_BLOCKSIZE_ERROR);

		logger.info("Decrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		this.setUpBadTargetFile();

		context = new ShellContext();
		params = new HashMap();

		params.put(CommandConstants.COMMAND_OPTION, CommandOption.FILE_DECRYPT);

		params.put(BaseConstants.FILE_IN, BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);

		decryptCommand.setContext(context);

		returnValue = decryptCommand.execute();

		if (isAssertON())
		{
			Assert.assertEquals(false, returnValue);
		}

		Assert.assertTrue(MessageCollectionHelper.verifyContextHasMessage(context,
				BaseTestConstants.EXCEPTION_ILLEGAL_BLOCK_SIZE, MessageLevel.SEVERE) == 1);

		logger.info("De-CryptCommand Tests Ends...");
		
		return;
	}

	@Test
	public void runTestDecryptCommandInvalidOptionFAIL()
	{
		Log logger = methIDrunTestDecryptCommandInvalidOptionFAIL;
		boolean returnValue = false;
		
		HashMap params = null;
		ShellContext context = null;

		// Result should be NO File.
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_EMPTY);
		
		// Set this to true, as the files should NOT match!   
		this.setTargetFileMatches( false );

		logger.info("Decrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		context = new ShellContext();

		params = new HashMap();

		// Set this to ENCRYPT!!!!
		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_ENCRYPT );
		
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_MISSING);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);

		decryptCommand.setContext(context);

		logger.debug("Running Decryption.....");

		returnValue = decryptCommand.execute();

		if ( isAssertON() )
		{			
			Assert.assertFalse(returnValue);
		}

		Assert.assertTrue(MessageCollectionHelper.verifyContextHasMessage(context,
				BaseTestConstants.ERROR_OPTION + CommandOption.FILE_ENCRYPT.toString(), 
				MessageLevel.SEVERE) == 1);
		
		logger.info("De-CryptCommand Tests Ends...");

		return;
		
	}	
	

	// Disabled due to file-system inconsistencies between WinTell & AIX
	//@Test
	public void runTestDecryptCommandBasicStringSUCCESS()
	{
		Log logger = methIDrunTestDecryptCommandBasicStringSUCCESS;
		boolean returnValue = false;

		logger.info("Decrypt Command Tests Begins...");

		HashMap<String, Object> params = null;
		ShellContext context = null;

		// Set this to true, as the files should match!
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_TEXT);
		
		this.setTargetFileMatches( true );
		
		logger.info("Decrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		context = new ShellContext();
		params = new HashMap<String, Object>();

		params.put(CommandConstants.COMMAND_OPTION,
				CommandOption.FILE_DECRYPT);

		params.put(BaseConstants.FILE_IN,
				BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);

		decryptCommand.setContext(context);

		returnValue = decryptCommand.execute();

		if ( isAssertON() )
		{
			Assert.assertTrue( returnValue );			
		}

		logger.info("De-CryptCommand Tests Ends...");

		return;

	}

	@After
	public void checkOutputFileMatch()
	{

		Log logger = methIDCheckOutputFileMatch;

		boolean returnValue = false;

		logger.debug(BaseConstants.BEGINS);

		if (!this.getTargetFileResult().equals(
				TargetFileOption.TEST_FILE_CONTENTS_EMPTY))
		{
			returnValue = this.checkTargetFile(this.getTargetFileResult()
					.toString());

			if ( isAssertON() )
			{
				Assert.assertEquals(this.isTargetFileMatches(), returnValue);
			}

		}

		logger.debug(BaseConstants.ENDS);

		return;

	}

	private void setUpBadTargetFile()
	{

		Log logger = methIDSetUpBadTargetFile;

		logger.debug(BaseConstants.BEGINS);

		this.writeTargetFile(this.getTargetFileResult().toString());

		logger.debug(BaseConstants.ENDS);

		return;
	}

}
