/*
 * Created by Eric Manley on Dec 12, 2008 
 */

package com.shell.aop.interceptor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Interceptor that provides trace logging for all non-domain, non-aspect
 * classes, if enabled.
 * 
 * @author Manley
 */
@Aspect
public class LoggingInterceptor
{
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Around("(( execution(* com.shell..*.*(..)) || execution(* com.shell..*.*(..)) ) "
			+ " && !(execution(* com.shell.domain.*.*(..)))"
			+ " && !(execution(* com.shell.aop.*.*(..))) )")
	public Object doLogging(ProceedingJoinPoint joinPoint) throws Throwable
	{
		if ( log.isDebugEnabled() )
		{
			String lineItem = joinPoint.toShortString();

			lineItem = lineItem.substring(lineItem.indexOf("(") + 1,
					lineItem.indexOf(")"))
					+ "()";

			log.debug("{}.{} BeginsAOP...", new Object[]
			{ // Skipp word "class"
							joinPoint.getTarget().getClass().toString()
									.substring(6), lineItem
					});

		}

		final Object returnValue = joinPoint.proceed(joinPoint.getArgs());

		if ( log.isDebugEnabled() )
		{
			String lineItem = joinPoint.toShortString();

			lineItem = lineItem.substring(lineItem.indexOf("(") + 1,
					lineItem.indexOf(")"))
					+ "()";

			log.debug("{}.{} EndsAOP...", new Object[]
			{
					joinPoint.getTarget().getClass().toString().substring(6),
					lineItem
			});
		}

		return returnValue;
	}

}
