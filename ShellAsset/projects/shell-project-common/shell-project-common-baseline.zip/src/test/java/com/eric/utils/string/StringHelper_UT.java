/**
* ---------------------------------------------------------------------------
* COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
* These materials are confidential and proprietary to  Citigroup, Inc.
* No part of this code may be reproduced, published in
* any form by any means (electronic or mechanical, including photocopy or
* any information storage or retrieval system), nor may the materials be
* disclosed to third parties, or used in derivative works without the
* express written authorization of Citigroup, Inc.
* ---------------------------------------------------------------------------
*/
package com.eric.utils.string;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.eric.test.AbstractBaseTestCase;
import com.shell.domain.common.constant.BaseConstants;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()

public class StringHelper_UT extends AbstractBaseTestCase
{
	
	private final static Log methIDrunTestStringIsNullSUCCESS;
	private final static Log methIDrunTestStringIsEmptySUCCESS;
	private final static Log methIDrunTestStringNotEmptyNotNullSUCCESS;	
	private final static Log methIDrunTestStringIsBlankSpaceSUCCESS;	

	static
	{
		methIDrunTestStringIsNullSUCCESS				= LogFactory.getLog(StringHelper_UT.class.getName() + ".runTestStringIsNullSUCCESS()");
		methIDrunTestStringIsEmptySUCCESS				= LogFactory.getLog(StringHelper_UT.class.getName() + ".runTestStringIsEmptySUCCESS()");
		methIDrunTestStringNotEmptyNotNullSUCCESS		= LogFactory.getLog(StringHelper_UT.class.getName() + ".runTestStringNotEmptyNotNullSUCCESS()");
		methIDrunTestStringIsBlankSpaceSUCCESS			= LogFactory.getLog(StringHelper_UT.class.getName() + ".runTestStringIsBlankSpaceSUCCESS()");		
	}	
	@Autowired

	@Test
	public void runTestStringIsNullSUCCESS()
	{		
		Log logger 				= methIDrunTestStringIsNullSUCCESS;
		boolean returnValue		= false;
		
		logger.debug(BaseConstants.BEGINS);
		
		returnValue = StringHelper.isNullOrEmpty( null );		
		
		Assert.assertTrue( returnValue );

		logger.debug(BaseConstants.ENDS);		
		
		return;
	}	
	
	@Test
	public void runTestStringIsEmptySUCCESS()
	{		
		Log logger 				= methIDrunTestStringIsEmptySUCCESS;
		boolean returnValue		= false;
		
		logger.debug(BaseConstants.BEGINS);
		
		returnValue = StringHelper.isNullOrEmpty( BaseConstants.BLANK_STRING );		
		
		Assert.assertTrue( returnValue );

		logger.debug(BaseConstants.ENDS);		
		
		return;
	}	
	
	@Test
	public void runTestStringNotEmptyNotNullSUCCESS()
	{		
		Log logger 				= methIDrunTestStringNotEmptyNotNullSUCCESS;
		boolean returnValue		= false;
		
		logger.debug(BaseConstants.BEGINS);
		
		returnValue = StringHelper.isNullOrEmpty( "foo" );		
		
		Assert.assertFalse( returnValue );

		logger.debug(BaseConstants.ENDS);		
		
		return;
	}		
	
	@Test
	public void runTestStringIsBlankSpaceSUCCESS()
	{		
		Log logger 				= methIDrunTestStringIsBlankSpaceSUCCESS;
		boolean returnValue		= false;
		
		logger.debug(BaseConstants.BEGINS);
		
		returnValue = StringHelper.isNullOrEmpty( BaseConstants.SPACE );		
		
		Assert.assertFalse( returnValue );

		logger.debug(BaseConstants.ENDS);		
		
		return;
	}		
	
	
	
	public void runAllTests()
	{

		return;
	}	
}