/**
* ---------------------------------------------------------------------------
* COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
* These materials are confidential and proprietary to  Citigroup, Inc.
* No part of this code may be reproduced, published in
* any form by any means (electronic or mechanical, including photocopy or
* any information storage or retrieval system), nor may the materials be
* disclosed to third parties, or used in derivative works without the
* express written authorization of Citigroup, Inc.
* ---------------------------------------------------------------------------
*/
package com.shell.command.crypto;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.shell.command.Command;
import com.shell.domain.common.constant.BaseConstants;
import com.shell.domain.common.constant.CommandConstants;
import com.shell.domain.common.constant.ErrorMessageConstants;
import com.shell.domain.common.enumeration.CommandOption;
import com.shell.domain.common.enumeration.MessageLevel;
import com.shell.domain.common.enumeration.TargetFileOption;
import com.shell.domain.common.message.MessageCollectionHelper;
import com.shell.domain.constant.BaseTestConstants;
import com.shell.domain.context.ShellContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()

public class EncryptCommandTest_UT extends AbstractBaseCryptoTestCommand
{

	@Autowired
	@Qualifier("encryptCommand") 
	private Command encryptCommand;

	@Autowired
	@Qualifier("decryptCommand")
	private Command decryptCommand;

	private static Log methIDrunTestEncryptCommandNullContextFAIL;	
	private static Log methIDrunTestEncryptCommandPasswordTooShortFAIL;
	private static Log methIDrunTestEncryptCommandBasicFileMissingFileFAIL;
	private static Log methIDrunTestEncryptCommandInvalidOptionFAIL;
	private static Log methIDrunTestEncryptCommandBasicFileSUCCESS;
	private static Log methIDrunTestEncryptCommandBasicStringSUCCESS;
	private static Log methIDrunTestEncryptCommandEncryptAndDecryptFileSUCCESS;
	
	private static Log methIDSetUpDefaultTargetFile;
	private static Log methIDCheckOutputFileMatch;
	
	static
	{
		methIDrunTestEncryptCommandNullContextFAIL = LogFactory
				.getLog(EncryptCommandTest_UT.class.getName()
						+ ".runTestEncryptCommandNullContextFAIL()");
		
		methIDrunTestEncryptCommandPasswordTooShortFAIL = LogFactory
				.getLog(EncryptCommandTest_UT.class.getName()
						+ ".runTestEncryptCommandPasswordTooShortFAIL()");
		
		methIDrunTestEncryptCommandBasicFileMissingFileFAIL = LogFactory
				.getLog(EncryptCommandTest_UT.class.getName()
						+ ".runTestEncryptCommandBasicFileMissingFileFAIL()"); 

		methIDrunTestEncryptCommandInvalidOptionFAIL = LogFactory
				.getLog(EncryptCommandTest_UT.class.getName()
						+ ".runTestDecryptCommandInvalidOptionFAIL()");		

		methIDrunTestEncryptCommandBasicFileSUCCESS = LogFactory
				.getLog(EncryptCommandTest_UT.class.getName()
						+ ".runTestEncryptCommandBasicFileSUCCESS()");
		
		methIDrunTestEncryptCommandEncryptAndDecryptFileSUCCESS = LogFactory
				.getLog(EncryptCommandTest_UT.class.getName()
						+ ".runTestEncryptCommandEncryptAndDecryptFileSUCCESS()");		

		methIDrunTestEncryptCommandBasicStringSUCCESS = LogFactory
				.getLog(EncryptCommandTest_UT.class.getName()
						+ ".runTestEncryptCommandBasicStringSUCCESS()");		
		
		methIDSetUpDefaultTargetFile = LogFactory
				.getLog(EncryptCommandTest_UT.class.getName()
						+ ".setUpDefaultTargetFile()");
		
		methIDCheckOutputFileMatch = LogFactory
				.getLog(EncryptCommandTest_UT.class.getName()
						+ ".checkOutputFileMatch()");
	}

	
	public  void EncryptCommandTest_UT()
	{
		this.EncryptCommandTest_UT( true );
	}
	
	public  void EncryptCommandTest_UT(boolean newValue)
	{
		this.setAssertON( newValue );
	}	
	
	public void runAllTests()
	{	
		
		this.runTestEncryptCommandNullContextFAIL();
		
		this.setUpDefaultTargetFile();		
		
		this.runTestEncryptCommandBasicFileSUCCESS();		
		this.runTestEncryptCommandBasicStringSUCCESS();
		
		this.checkOutputFileMatch();
		
		return;
	}	
	@Before
	public void setUpDefaultTargetFile()
	{

		Log logger = methIDSetUpDefaultTargetFile;

		logger.debug(BaseConstants.BEGINS);

		this.writeTargetFile(BaseTestConstants.TEST_FILE_CONTENTS_TEXT);

		logger.debug(BaseConstants.ENDS);

		return;
	}

	@Test
	public void runTestEncryptCommandNullContextFAIL()
	{
		Log logger = methIDrunTestEncryptCommandNullContextFAIL;
		boolean returnValue = false;

		Command eCmd = null;
		HashMap<String, Object> params = null;
		ShellContext context = null;
		
		// Set this to false, as the files should match!
		this.setTargetFileMatches( false );
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_EMPTY);
		
		logger.info("Encrypt Command Tests Begins...");
		logger.debug("Initializing.....");
		
		context = new ShellContext();

		params = new HashMap<String, Object>();

		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_ENCRYPT );
		
		params.put( BaseConstants.FILE_IN,
				    BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, BaseTestConstants.GOOD_PASSWORD);

		context.setParams( params );
		
		// PURPOSEFULLY DO NOT DO THIS!!!  LEAVE NULL!!!
		// encryptCommand.setContext( context );

		returnValue = encryptCommand.execute();

		if ( isAssertON() )
		{
			Assert.assertFalse(returnValue);			
		}

		logger.info("EncryptCommand Tests Ends...");

		return;

	}
	
	@Test
	public void runTestEncryptCommandPasswordTooShortFAIL()
	{
		Log logger = methIDrunTestEncryptCommandPasswordTooShortFAIL;
		boolean returnValue = false;

		HashMap<String, Object> params = null;
		ShellContext context = null;

		// Set this to true, as the files should match!
		this.setTargetFileMatches( true );

		// Set this as Empty to skip it..
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_EMPTY);
		
		logger.info("Encrypt Command Tests Begins...");
		logger.debug("Initializing.....");
		

		context = new ShellContext();

		params = new HashMap<String, Object>();

		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_ENCRYPT );
		
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.BAD_PASSWORD_TOO_SHORT);

		context.setParams(params);

		encryptCommand.setContext(context);

		logger.debug("Running Encryption.....");

		returnValue = encryptCommand.execute();

		if ( isAssertON() )
		{			
			Assert.assertFalse( returnValue );
		
			Assert.assertTrue(MessageCollectionHelper.verifyContextHasMessage(context,
					ErrorMessageConstants.PASSWORD_TOO_SHORT, MessageLevel.SEVERE) == 1);
		
		}

		logger.info("EncryptCommand Tests Ends...");

		return;
		
	}	

	@Test
	public void runTestEncryptCommandBasicFileMissingFileFAIL()
	{
		Log logger = methIDrunTestEncryptCommandBasicFileMissingFileFAIL;
		boolean returnValue = false;
		
		HashMap params = null;
		ShellContext context = null;

		// Result should be NO File.
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_EMPTY);
		
		// Set this to true, as the files should NOT match!   
		this.setTargetFileMatches( false );

		logger.info("Encrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		context = new ShellContext();

		params = new HashMap();

		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_ENCRYPT );
		
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_MISSING);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);

		encryptCommand.setContext(context);

		logger.debug("Running Encryption.....");

		returnValue = encryptCommand.execute();

		if ( isAssertON() )
		{			
			Assert.assertFalse(returnValue);
		}

		Assert.assertTrue(MessageCollectionHelper.verifyContextHasMessage(context,
				BaseTestConstants.EXCEPTION_FILE_NOT_FOUND, MessageLevel.SEVERE) == 1);
		
		logger.info("EncryptCommand Tests Ends...");

		return;
	}	
	
	@Test
	public void runTestEncryptCommandInvalidOptionFAIL()
	{
		Log logger = methIDrunTestEncryptCommandInvalidOptionFAIL;
		boolean returnValue = false;
		
		HashMap params = null;
		ShellContext context = null;

		// Result should be NO File.
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_EMPTY);
		
		// Set this to true, as the files should NOT match!   
		this.setTargetFileMatches( false );

		logger.info("Encrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		context = new ShellContext();

		params = new HashMap();

		// Set this to DECRYPT!!!!
		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_DECRYPT );
		
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_MISSING);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);

		encryptCommand.setContext(context);

		logger.debug("Running Encryption.....");

		returnValue = encryptCommand.execute();

		if ( isAssertON() )
		{			
			Assert.assertFalse(returnValue);
		}

		Assert.assertTrue(MessageCollectionHelper.verifyContextHasMessage(context,
				BaseTestConstants.ERROR_OPTION + CommandOption.FILE_DECRYPT.toString(), 
				MessageLevel.SEVERE) == 1);
		
		logger.info("EncryptCommand Tests Ends...");

		return;
		
	}		
	
	@Test
	public void runTestEncryptCommandBasicFileSUCCESS()
	{
		Log logger = methIDrunTestEncryptCommandBasicFileSUCCESS;
		boolean returnValue = false;

		HashMap params = null;
		ShellContext context = null;

		// Result should be encrypted file.
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_ENCRYPTED);
		
		// Set this to true, as the files should NOT match!   
		// This shows the random salt is working.
		this.setTargetFileMatches( false );

		logger.info("Encrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		context = new ShellContext();

		params = new HashMap();

		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_ENCRYPT );
		
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);

		encryptCommand.setContext(context);

		logger.debug("Running Encryption.....");

		returnValue = encryptCommand.execute();

		if ( isAssertON() )
		{			
			Assert.assertTrue(returnValue);
		}

		logger.info("EncryptCommand Tests Ends...");

		return;

	}
	
	@Test
	public void runTestEncryptCommandEncryptAndDecryptFileSUCCESS()
	{
		Log logger = methIDrunTestEncryptCommandEncryptAndDecryptFileSUCCESS;
		boolean returnValue = false;


		HashMap params = null;
		ShellContext context = null;

		// Result should be plain text.
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_TEXT);
		
		// Set this to true, as the files should match!
		this.setTargetFileMatches( true );

		logger.info("Encrypt Command Tests Begins...");
		logger.debug("Initializing.....");

		context = new ShellContext();

		params = new HashMap();

		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_ENCRYPT );
		
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);

		encryptCommand.setContext(context);

		logger.debug("Running Encryption.....");

		returnValue = encryptCommand.execute();

		if ( isAssertON() )
		{			
			Assert.assertTrue(returnValue);
		}

		context = null;
		context = new ShellContext();

		params = new HashMap();

		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.FILE_DECRYPT );
		
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.GOOD_PASSWORD);

		context.setParams(params);		
		
		decryptCommand.setContext(context);

		logger.debug("Running Decryption.....");

		returnValue = decryptCommand.execute();

		if ( isAssertON() )
		{
			Assert.assertTrue(returnValue);
		}

		logger.info("EncryptCommand Tests Ends...");

		return;
		
	}	
	
	@Test
	public void runTestEncryptCommandBasicStringSUCCESS()
	{
		Log logger = methIDrunTestEncryptCommandBasicStringSUCCESS;
		boolean returnValue = false;

		HashMap params = null;
		ShellContext context = null;

		// Set this to true.
		this.setTargetFileMatches( false );
		// Result should be plain text.
		this.setTargetFileResult(TargetFileOption.TEST_FILE_CONTENTS_EMPTY);	
		
		logger.info("Encrypt Command Tests Begins...");
		logger.debug("Initializing.....");
		
		context = new ShellContext();

		params = new HashMap();

		params.put( CommandConstants.COMMAND_OPTION,
					CommandOption.STRING_ENCRYPT );

		
		// Add String-Key Here...
		params.put(BaseConstants.FILE_IN,
				   BaseTestConstants.TEST_FILE_NAME_GOOD);

		params.put(BaseConstants.PASSWORD, 
				   BaseTestConstants.GOOD_PASSWORD);

		context.setParams( params );

		encryptCommand.setContext(context);

		logger.debug("Running Encryption.....");

		returnValue = encryptCommand.execute();

		if ( isAssertON() )
		{			
			Assert.assertTrue(returnValue);
		}

		logger.info("EncryptCommand Tests Ends...");
		
		return;
	}	
	
	@After
	public void checkOutputFileMatch()
	{

		Log logger = methIDCheckOutputFileMatch;

		boolean returnValue = false;
		String targetFileResultString = null;
		
		logger.debug(BaseConstants.BEGINS);
		
		if ( !this.getTargetFileResult().equals( TargetFileOption.TEST_FILE_CONTENTS_EMPTY ))
		{
			
			returnValue = this.checkTargetFile( this.getTargetFileResult().toString() );

			if ( isAssertON() )
			{
				Assert.assertEquals(this.isTargetFileMatches(), returnValue);			
			}
	
			logger.debug(BaseConstants.ENDS);

		}
		
		return;

	}

}
