/**
* ---------------------------------------------------------------------------
* COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
* These materials are confidential and proprietary to  Citigroup, Inc.
* No part of this code may be reproduced, published in
* any form by any means (electronic or mechanical, including photocopy or
* any information storage or retrieval system), nor may the materials be
* disclosed to third parties, or used in derivative works without the
* express written authorization of Citigroup, Inc.
* ---------------------------------------------------------------------------
*/
package com.shell.domain.constant;

import com.shell.domain.common.constant.BaseConstants;

public class BaseTestConstantsShellUtils
{
	/*
	public static final String GOOD_CONFIG_FILE		 							= BaseConstants.DEFAULT_CONFIG_PATH + 
																					"citi-rel-utils-project-common-config.xml";
	
	public static final String CORRUPT_CONFIG_FILE 								= BaseConstants.DEFAULT_CONFIG_PATH +
																					"citi-rel-utils-project-common-config-CORRUPT.xml";	

	public static final String WS_URL 											= "WS_URL";
	public static final String WS_URL_ELEMENT_DOES_NOT_EXIST					= "WS_URL_ELEMENT_DOES_NOT_EXIST";	
	public static final String WS_URL_RESULT_DEFAULT							= "https://relap-dev5501.nam.nsroot.net:58214/Rel/Services/Security/MFAService";
	public static final String WS_URL_RESULT_LOCAL								= "http://relap-dev5501.nam.nsroot.net:60015/Rel/Services/Security/MFAService";
	public static final String CANNOT_GET_URL_FOR_FILENAME_ERR_MSG				= "Unable to get URL for FileName";
	
	public static final String ENVIRONMENT_LOCALX								= "LOCALX";	
	*/
}
