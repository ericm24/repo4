/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */
package com.eric.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.shell.domain.common.constant.BaseConstants;
import com.shell.domain.common.enumeration.MessageLevel;
import com.shell.domain.common.message.Message;
import com.shell.domain.common.message.MessageCollection;

public class EricTestHelper
{

	private final static Log methIDcreateMessageCollection3GroupsAllLevels;	
	
	
	static
	{
		methIDcreateMessageCollection3GroupsAllLevels							= LogFactory.getLog(EricTestHelper.class.getName() + ".createMessageCollection3GroupsAllLevels()");		
	}
	
	public static MessageCollection createMessageCollection3GroupsAllLevels()
	{
		
		Log logger 				= methIDcreateMessageCollection3GroupsAllLevels;
		
		MessageCollection mc1 	= null;
		Message msg				= null;
		int i					= 0;
		
		logger.debug(BaseConstants.BEGINS);
		
		mc1 = new MessageCollection();
		
		for (MessageLevel messageLevel : MessageLevel.values() ) 
		{
			logger.info("Adding Messages of Level: " + messageLevel.toString());
			msg = new Message(messageLevel, messageLevel.toString() + " Message Text: " + i + " GroupB"); 
			
			// Add them ALL to first Collection.
			logger.debug("Adding To Collection1 messageID: " + msg.getID() + " level: " + msg.getLevel().toString() + " text: " + msg.getText() );
			mc1.add( msg );

			i++;
			msg = null;
		}
		
		for (MessageLevel messageLevel : MessageLevel.values() ) 
		{
			logger.info("Adding Messages of Level: " + messageLevel.toString());
			msg = new Message(messageLevel, messageLevel.toString() + " Message Text: " + i + " GroupA"); 
			
			// Add them ALL to first Collection.
			logger.debug("Adding To Collection1 messageID: " + msg.getID() + " level: " + msg.getLevel().toString() + " text: " + msg.getText() );
			mc1.add( msg );

			i++;
			msg = null;
		}
		
		for (MessageLevel messageLevel : MessageLevel.values() ) 
		{
			logger.info("Adding Messages of Level: " + messageLevel.toString());
			msg = new Message(messageLevel, messageLevel.toString() + " Message Text: " + i + " GroupC"); 
			
			// Add them ALL to first Collection.
			logger.debug("Adding To Collection1 messageID: " + msg.getID() + " level: " + msg.getLevel().toString() + " text: " + msg.getText() );
			mc1.add( msg );

			i++;
			msg = null;
		}
		
		logger.debug(BaseConstants.ENDS);
		
		return( mc1 );
		
	}	
}
