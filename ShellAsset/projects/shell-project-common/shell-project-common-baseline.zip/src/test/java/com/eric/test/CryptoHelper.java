/**
* ---------------------------------------------------------------------------
* COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
* These materials are confidential and proprietary to  Citigroup, Inc.
* No part of this code may be reproduced, published in
* any form by any means (electronic or mechanical, including photocopy or
* any information storage or retrieval system), nor may the materials be
* disclosed to third parties, or used in derivative works without the
* express written authorization of Citigroup, Inc.
* ---------------------------------------------------------------------------
*/
package com.eric.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.shell.domain.common.constant.BaseConstants;
import com.shell.domain.constant.BaseTestConstants;

public class CryptoHelper
{
	
	private static Log methIDWriteTargetFile;
	private static Log methIDCheckTargetFile;

	static
	{
		methIDWriteTargetFile = LogFactory.getLog(CryptoHelper.class
				.getName()
				+ ".writeTargetFile()");
		methIDCheckTargetFile = LogFactory.getLog(CryptoHelper.class
				.getName()
				+ ".checkTargetFile()");
	}
	
	
	public void writeTargetFile(String targetStringValue)
	{

		Log logger = methIDWriteTargetFile;

		logger.debug(BaseConstants.BEGINS);

		boolean returnValue = false;

		File targetFile = null;
		File sourceFile = null;

		FileOutputStream outFile = null;
		FileInputStream inFile = null;

		targetFile = new File(BaseTestConstants.TEST_FILE_NAME_GOOD);

		// Delete it first to make sure it does not exist.
		returnValue = targetFile.delete();


		try
		{
			outFile = new FileOutputStream(
					BaseTestConstants.TEST_FILE_NAME_GOOD);

			byte output[] = targetStringValue.getBytes();
			outFile.write(output);
			outFile.flush();
			outFile.close();

		}
		catch (Exception ex)
		{
			// fail("Exception Encountered: " + ex.getMessage());
			logger.fatal("Exception Encountered: " + ex.getMessage());

		}

		logger.debug(BaseConstants.ENDS);

		return;
	}

	public boolean checkTargetFile(String matchString)
	{
		Log logger = methIDCheckTargetFile;

		logger.debug(BaseConstants.BEGINS);

		boolean returnValue = false;

		File targetFile = null;
		File sourceFile = null;

		byte input[] = null;
		FileInputStream inFile = null;
		String fileString = null;
		int maxLen = 0;

		targetFile = new File(BaseTestConstants.TEST_FILE_NAME_GOOD);

		try
		{

			inFile = new FileInputStream(BaseTestConstants.TEST_FILE_NAME_GOOD);
			input = new byte[64];

			inFile.read(input);

			inFile.close();

			fileString = new String(input);

			maxLen = matchString.length();
			fileString = fileString.substring(0, maxLen);

			returnValue = fileString.equals(matchString) ? true : false;


		}
		catch (Exception ex)
		{
			// fail("Exception Encountered: " + ex.getMessage());
			
			logger.fatal("Exception Encountered: " + ex.getMessage());

		}

		logger.debug(BaseConstants.ENDS);

		return (returnValue);
	}

}
