/**
* ---------------------------------------------------------------------------
* COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
* These materials are confidential and proprietary to  Citigroup, Inc.
* No part of this code may be reproduced, published in
* any form by any means (electronic or mechanical, including photocopy or
* any information storage or retrieval system), nor may the materials be
* disclosed to third parties, or used in derivative works without the
* express written authorization of Citigroup, Inc.
* ---------------------------------------------------------------------------
*/
package com.shell.command.crypto;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.eric.test.AbstractBaseTestCase;
import com.eric.test.CryptoHelper;
import com.shell.domain.common.constant.BaseConstants;
import com.shell.domain.common.enumeration.TargetFileOption;

public abstract class AbstractBaseCryptoTestCommand extends AbstractBaseTestCase
{

	private final static Log methIDWriteTargetFile;
	private final static Log methIDCheckTargetFile;	
	private final static CryptoHelper cryptoHelper;
	
	static
	{
		methIDWriteTargetFile = LogFactory.getLog(AbstractBaseCryptoTestCommand.class
				.getName()
				+ ".writeTargetFile()");
		methIDCheckTargetFile = LogFactory.getLog(AbstractBaseCryptoTestCommand.class
				.getName()
				+ ".checkTargetFile()");
		
		cryptoHelper = new CryptoHelper();		
	}


	private boolean targetFileMatches 			= true;	
	private TargetFileOption targetFileResult 	= null;
	 	
	
	protected void writeTargetFile(String targetStringValue)
	{

		Log logger = methIDWriteTargetFile;

		logger.debug(BaseConstants.BEGINS);

		cryptoHelper.writeTargetFile(targetStringValue);
		
		
		logger.debug(BaseConstants.ENDS);

		return;
	}

	protected boolean checkTargetFile(String matchString)
	{
		Log logger = methIDCheckTargetFile;

		logger.debug(BaseConstants.BEGINS);

		boolean returnValue = false;
		
		returnValue = cryptoHelper.checkTargetFile( matchString );
		
		logger.debug(BaseConstants.ENDS);

		return ( returnValue );
	}

	public boolean isTargetFileMatches()
	{
		return targetFileMatches;
	}

	public void setTargetFileMatches(boolean targetFileMatches)
	{
		this.targetFileMatches = targetFileMatches;
	}

	public TargetFileOption getTargetFileResult()
	{
		return targetFileResult;
	}

	public void setTargetFileResult(TargetFileOption targetFileResult)
	{
		this.targetFileResult = targetFileResult;
	}
	
}
