/**
* ---------------------------------------------------------------------------
* COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
* These materials are confidential and proprietary to  Citigroup, Inc.
* No part of this code may be reproduced, published in
* any form by any means (electronic or mechanical, including photocopy or
* any information storage or retrieval system), nor may the materials be
* disclosed to third parties, or used in derivative works without the
* express written authorization of Citigroup, Inc.
* ---------------------------------------------------------------------------
*/
package com.shell.command.crypto;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.eric.test.AbstractBaseTestCase;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()


// Primary function of this class is to use DI for deps, and enable AOP.

public class Crypto_TS extends AbstractBaseTestCase
{
	
	@Autowired
	@Qualifier("decryptCommandTest_UT")
	private DecryptCommandTest_UT decryptCommandTest_UT;
	
	@Autowired
	@Qualifier("encryptCommandTest_UT")
	private EncryptCommandTest_UT encryptCommandTest_UT;

	private boolean masterFlag = true;	

	
	public void runAllTests()
	{

		this.runDecryptTests();
		
		this.runEncryptTests();
		
		return;
	}
	
	
	
	@Test
	public void runDecryptTests()
	{		
		
		//masterFlag = false;
		decryptCommandTest_UT.setAssertON( masterFlag );		
		
		// Notice the difference in the # of methods you get AOP book-end
		// logging for by calling the .runAllTests() [ which wraps  the same 
		// methods ] instead of calling them individually.
		
		// Called individually, you get AOP book-end logging on each
		decryptCommandTest_UT.runTestDecryptCommandNullContextFAIL();		
		
		decryptCommandTest_UT.setUpDefaultTargetFile();
		decryptCommandTest_UT.runTestDecryptCommandBasicFileMissingFileFAIL();
		decryptCommandTest_UT.checkOutputFileMatch();
		
		decryptCommandTest_UT.setUpDefaultTargetFile();
		decryptCommandTest_UT.runTestDecryptCommandIllegalBlockSizeFAIL();
		decryptCommandTest_UT.checkOutputFileMatch();
	
		decryptCommandTest_UT.setUpDefaultTargetFile();
		decryptCommandTest_UT.runTestDecryptCommandPasswordTooShortFAIL();
		decryptCommandTest_UT.checkOutputFileMatch();

		decryptCommandTest_UT.setUpDefaultTargetFile();
		decryptCommandTest_UT.runTestDecryptCommandBasicStringSUCCESS();
		decryptCommandTest_UT.checkOutputFileMatch();
		
		return;
	}


	@Test
	public void runEncryptTests()
	{
		//masterFlag = false;		

		encryptCommandTest_UT.setAssertON( masterFlag );

		// Notice the difference in the # of methods you get AOP book-end
		// logging for by calling the .runAllTests() [ which wraps  the same 
		// methods ] instead of calling them individually.

		// Called individually, you get AOP book-end logging on each

		encryptCommandTest_UT.runTestEncryptCommandNullContextFAIL();		
		
		encryptCommandTest_UT.setUpDefaultTargetFile();
		encryptCommandTest_UT.runTestEncryptCommandPasswordTooShortFAIL();
		encryptCommandTest_UT.checkOutputFileMatch();
		
		encryptCommandTest_UT.setUpDefaultTargetFile();
		encryptCommandTest_UT.runTestEncryptCommandBasicFileMissingFileFAIL();
		encryptCommandTest_UT.checkOutputFileMatch();
		
		encryptCommandTest_UT.setUpDefaultTargetFile();
		encryptCommandTest_UT.runTestEncryptCommandBasicFileSUCCESS();
		encryptCommandTest_UT.checkOutputFileMatch();
		
		encryptCommandTest_UT.setUpDefaultTargetFile();
		encryptCommandTest_UT.runTestEncryptCommandEncryptAndDecryptFileSUCCESS();
		encryptCommandTest_UT.checkOutputFileMatch();

		encryptCommandTest_UT.setUpDefaultTargetFile();
		encryptCommandTest_UT.runTestEncryptCommandBasicStringSUCCESS();
		encryptCommandTest_UT.checkOutputFileMatch();
		
		
		return;
	}
	
	

}
