/**
* ---------------------------------------------------------------------------
* COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
* These materials are confidential and proprietary to  Citigroup, Inc.
* No part of this code may be reproduced, published in
* any form by any means (electronic or mechanical, including photocopy or
* any information storage or retrieval system), nor may the materials be
* disclosed to third parties, or used in derivative works without the
* express written authorization of Citigroup, Inc.
* ---------------------------------------------------------------------------
*/
package com.shell.command.crypto.test.suite;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.shell.command.crypto.DecryptCommandTest_UT;
import com.shell.command.crypto.EncryptCommandTest_UT;


@RunWith( Suite.class )
@Suite.SuiteClasses({
						EncryptCommandTest_UT.class,
						DecryptCommandTest_UT.class
					})
/**
 * This Suite is the FULL-REGRESSION test Suite (ie Non-DIT).
 *  
 * @author em32459
 * 
 */							
public class CryptoFullRegressionTestSuite
{

	private static final Log methIDfirstMethod;
	private static final Log methIDlastMethod;
	
	static 
	{
		methIDfirstMethod = LogFactory
			.getLog(CryptoFullRegressionTestSuite.class.getName() + ".firstMethod()");
		
		methIDlastMethod = LogFactory
			.getLog(CryptoFullRegressionTestSuite.class.getName() + ".lastMethod()");
		
	}	
	
	@BeforeClass
	public static void firstMethod()
	{		
		Log logger = methIDfirstMethod;		
		logger.info("Start of Test Suite....");		
		return;
	}	
	
	@AfterClass
	public static void lastMethod()
	{
		Log logger = methIDlastMethod;		
		logger.info("End of Test Suite....");		
		return;
	}
	
}
