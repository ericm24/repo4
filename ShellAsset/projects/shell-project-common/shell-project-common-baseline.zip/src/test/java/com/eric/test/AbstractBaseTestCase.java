/**
* ---------------------------------------------------------------------------
* COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
* These materials are confidential and proprietary to  Citigroup, Inc.
* No part of this code may be reproduced, published in
* any form by any means (electronic or mechanical, including photocopy or
* any information storage or retrieval system), nor may the materials be
* disclosed to third parties, or used in derivative works without the
* express written authorization of Citigroup, Inc.
* ---------------------------------------------------------------------------
*/

package com.eric.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * A generic base class for Shell test cases.
 * 
 * @author
 * 
 */
public abstract class AbstractBaseTestCase implements EricTestCase
{
	private static Log methIDSetAssertON;

	private boolean assertON = true;

	private final static String SET_ASSERT_ON = "Setting ASSERTON To: %s";

	static
	{
		methIDSetAssertON = LogFactory.getLog(AbstractBaseTestCase.class.getName()
				+ ".setAssertON()");
	}

	
	public abstract void runAllTests();
	
	public boolean isAssertON()
	{
		return assertON;
	}

	public void setAssertON(boolean newValue)
	{
		Log logger = methIDSetAssertON;
		String lineItem = null;

		lineItem = String.format(this.SET_ASSERT_ON, newValue);

		logger.info( lineItem );

		this.assertON = newValue;

		return;
	}

}
