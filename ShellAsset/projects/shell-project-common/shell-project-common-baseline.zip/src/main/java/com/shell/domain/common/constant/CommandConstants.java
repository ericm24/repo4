/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */
package com.shell.domain.common.constant;

public final class CommandConstants 
{

	public final static String ENCRYPT 								= "encrypt";
	public final static String DECRYPT 								= "decrypt";

	public final static String COMMAND_OPTION 						= "COMMAND_OPTION"; 
	
	public final static String ERROR_MESSAGE_NULL_CONTEXT 			= "Context IS NULL!!";
	public final static String ERROR_MESSAGE_NULL_COMMAND_OPTION 	= "Command Option IS NULL!!"; 
	
	public final static String ERROR_INVALID_COMMAND_OPTION			= "Error Option: %s is Invalid For Command: %s";
 
	// Hide This!
	private CommandConstants()
	{		
	}
	
}
