/**
* ---------------------------------------------------------------------------
* COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
* These materials are confidential and proprietary to  Citigroup, Inc.
* No part of this code may be reproduced, published in
* any form by any means (electronic or mechanical, including photocopy or
* any information storage or retrieval system), nor may the materials be
* disclosed to third parties, or used in derivative works without the
* express written authorization of Citigroup, Inc.
* ---------------------------------------------------------------------------
*/
package com.eric.utils.string;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.shell.domain.common.constant.BaseConstants;

/**
 * Helper Class for Strings, String things.  
 * 
 * @author em32459
 * 
 */
public class StringHelper
{
	
	private static final Log methIDisNullOrEmpty;	

	static
	{
		methIDisNullOrEmpty = LogFactory
			.getLog(StringHelper.class.getName() + ".isNullOrEmpty()");
		
	}
	
	/**
	 * 
	 * Convenience method that checks a String to determine if it is null or empty. Stolen from .Net.
	 *
	 * @param StringInput
	 *  
	 * @return java.lang.String
	 * 
	 */	
	public static boolean isNullOrEmpty(String theString)
	{
		Log logger 				= methIDisNullOrEmpty;
		boolean returnValue 	= true;

		logger.debug( BaseConstants.BEGINS );

		if ( theString != null )
		{
			if ( theString.isEmpty() )
			{
				returnValue = true;
			}
			else
			{
				returnValue = false;
			}
		}
		
		logger.debug( BaseConstants.ENDS );
		
		return( returnValue );
	}	


}
