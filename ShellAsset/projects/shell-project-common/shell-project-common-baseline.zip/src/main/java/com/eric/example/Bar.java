package com.eric.example;

import org.apache.log4j.Logger;


public class Bar 
{

	private final static Logger methIDdoWork;

	
	static
	{
		methIDdoWork	 						= Logger.getLogger(Bar.class.getName() + ".doWork()");		
	}
	

	public String doWork()
	{
		Logger logger = methIDdoWork;
		
		String returnValue = "AnotherThing2Return4You";		
		
		logger.debug("Begins...");
	
		logger.debug("Ends...");	
	
		return( returnValue );
	}
	

	
}