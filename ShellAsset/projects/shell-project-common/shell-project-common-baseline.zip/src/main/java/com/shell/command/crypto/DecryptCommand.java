/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */
package com.shell.command.crypto;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.shell.domain.common.constant.BaseConstants;
import com.shell.domain.common.constant.CommandConstants;
import com.shell.domain.common.constant.CryptoConstants;
import com.shell.domain.common.constant.ErrorMessageConstants;
import com.shell.domain.common.enumeration.CommandOption;
import com.shell.domain.common.enumeration.MessageLevel;
import com.shell.domain.common.message.ExMessages;
import com.shell.domain.common.message.Message;

/**
 * Concrete Implementation for Command interface that performs Triple-Des decryption 
 * and follows GO4 Command Pattern.  .execute() & .undo() are required behavior methods.
 * 
 * @author em32459
 * 
 */
public class DecryptCommand extends AbstractBaseCryptoCommand 
{
	/**
	 * Note: As with the pervious example, all kinds of exceptions can be thrown
	 * in main. See the API documentation for each method used.
	 */

	
	private static final Log methIDExecute; 
	private static final Log methIDDecryptFile;
	private static final Log methIDDecryptString;	
	private static final Log methIDExecuteP;
	
	static 
	{
		methIDExecute = LogFactory
			.getLog(DecryptCommand.class.getName() + ".execute()");
	
		methIDDecryptFile = LogFactory
			.getLog(DecryptCommand.class.getName() + ".decryptFile()");

		methIDDecryptString = LogFactory
			.getLog(DecryptCommand.class.getName() + ".decryptString()");		
		
		methIDExecuteP = LogFactory
			.getLog("PERF." + DecryptCommand.class.getName() + ".execute()");
	}
	
	/**
     * Executes decryption algorythim on file specified in the context.
     * @return <CODE>true</CODE> if command successful.  
     * 
     *  If false, check the message collection.
     * 
     * <CODE>false</CODE> otherwise
     */
	@Override
	public boolean execute()
	{

		Log logger 	= methIDExecute;		
		Log loggerP = methIDExecuteP;
		boolean returnValue = false;

		String errorMsg 				= null;
		CommandOption commandOption 	= null;
		
		boolean keepOnTrucking			= true;

		logger.debug( BaseConstants.BEGINS );
		loggerP.info( BaseConstants.BEGINS );		
		
		while ( keepOnTrucking )
		{
			if ( context == null )
			{
				errorMsg = CommandConstants.ERROR_MESSAGE_NULL_CONTEXT;
				logger.error( errorMsg );
				keepOnTrucking = false;
				
				break;			
			}

			commandOption = (CommandOption)context.getParams().get( CommandConstants.COMMAND_OPTION ); 
		
			if (  commandOption == null )
			{
				errorMsg = CommandConstants.ERROR_MESSAGE_NULL_CONTEXT;
				logger.error( errorMsg );
				keepOnTrucking = false;			
			}
			
			if ( commandOption.equals( CommandOption.FILE_DECRYPT ))
			{
				returnValue = this.decryptFile();
			}
			else if ( commandOption.equals( CommandOption.STRING_DECRYPT ))
 			{
				returnValue = this.decryptString();				
			}	
			else
			{
				errorMsg = String.format(CommandConstants.ERROR_INVALID_COMMAND_OPTION, 
						                 commandOption,
						                 DecryptCommand.class.getName());
				
				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
				
				logger.error( errorMsg );
				keepOnTrucking = false;				
			}
				
			// Safety Purposes.
			keepOnTrucking = false;
		}

		loggerP.info( BaseConstants.ENDS );
		logger.debug( BaseConstants.ENDS );		

		
		return (returnValue);
	}

	/**
     * UNDO changes by execute method.  Restores context and object-graph 
     * to original form, and in this case returns target string as it existed
     * before, (could be encrypted or decrypted).
     * @return <CODE>true</CODE> if UNDO successful. 
     * <CODE>false</CODE> otherwise
     */
	@Override
	public boolean undo()
	{

		boolean returnValue = false;

		return (returnValue);
	}

	private boolean decryptFile()
	{
		boolean returnValue = false;
		String errorMsg = null;
		boolean keepOnTrucking = true;
		
		Log logger = methIDDecryptFile;

		logger.debug(BaseConstants.BEGINS);

		// File to decrypt. It does not have to be a text file!

		while( keepOnTrucking )
		{
		
			if (context == null)
			{
				errorMsg = CommandConstants.ERROR_MESSAGE_NULL_CONTEXT;
				logger.error(errorMsg);
				keepOnTrucking = false;
				break;
			}
			else
			{
				// TODO: Add Call to Validator!			
				this.setFileNameIn((String)context.getParams().get(BaseConstants.FILE_IN));
				this.setPassword((String)context.getParams().get(BaseConstants.PASSWORD));				
	
				// Password must be at least 8 characters (bytes) long
				if ( this.getPassword().length() < BaseConstants.MIN_PASSWORD_LENGTH )			
				{				
					errorMsg = ErrorMessageConstants.PASSWORD_TOO_SHORT;				
					logger.error(errorMsg);			
					
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, ErrorMessageConstants.PASSWORD_TOO_SHORT.toString()));
					keepOnTrucking = false;
					break;				
				}
				
				try
				{
					// Read it in.
					this.setInFile(new FileInputStream(this.getFileNameIn()));
					
					this.setFileNameTemp(this.getFileNameIn() + ".des");
					
					this.setOutFile(new FileOutputStream(this.getFileNameTemp()));
					
					// Use PBEKeySpec to create a key based on a password.
					// The password is passed as a character array
	
					PBEKeySpec keySpec = new PBEKeySpec(this.getPassword().toCharArray());					
					
					SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(CryptoConstants.PBEWITHMD5ANDDES);
					SecretKey passwordKey = keyFactory.generateSecret(keySpec);
	
					// Read in the previouly stored salt and set the iteration
					// count.
	
					byte[] salt = new byte[ CryptoConstants.SALT_SIZE ];
					
					this.getInFile().read(salt);
					
					int iterations = 100;
	
					PBEParameterSpec parameterSpec = new PBEParameterSpec(salt,
							iterations);
	
					// Create the cipher and initialize it for decryption.
	
					Cipher cipher = Cipher
							.getInstance(CryptoConstants.PBEWITHMD5ANDDES);
					cipher.init(Cipher.DECRYPT_MODE, passwordKey, parameterSpec);
	
					byte[] input = new byte[64];
					int bytesRead;
					
					for (bytesRead = this.getInFile().read(input); (bytesRead != BaseConstants.NO_BYTES_READ); )					
					{
												
						byte[] output = cipher.update(input, 0, bytesRead);
						if (output != null)
						{
							this.getOutFile().write(output);							
						}
						bytesRead = this.getInFile().read(input);						
					}
	
					byte[] output = cipher.doFinal();
					if (output != null)
					{
						this.getOutFile().write(output);						
					}
	
					returnValue = true;
	
				}
	
				catch (NoSuchPaddingException nspex)
				{
					errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
							NoSuchPaddingException.class.getName(), nspex
									.getMessage());
	
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
				}
	
				catch (InvalidAlgorithmParameterException iapex)
				{
					errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
							InvalidAlgorithmParameterException.class.getName(),
							iapex.getMessage());
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
				}
	
				catch (InvalidKeyException ikex)
				{
					errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
							InvalidKeyException.class.getName(), ikex.getMessage());
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
				}
	
				catch (InvalidKeySpecException iksex)
				{
					errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
							InvalidKeySpecException.class.getName(), iksex
									.getMessage());
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
				}
	
				catch (IllegalBlockSizeException ibsex)
				{
					errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
							IllegalBlockSizeException.class.getName(), ibsex
									.getMessage());
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
				}
	
				catch (BadPaddingException bpex)
				{
					errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
							BadPaddingException.class.getName(), bpex.getMessage());
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
	
				}
	
				catch (NoSuchAlgorithmException nsaex)
				{
					errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
							NoSuchAlgorithmException.class.getName(), nsaex
									.getMessage());
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
	
				}
	
				catch (FileNotFoundException fnfex)
				{
					errorMsg = String.format(
								ExMessages.GENEXCEPTION_ENCOUNTERED,
								FileNotFoundException.class.getName(), fnfex
										.getMessage());
	
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
				}
	
				catch (IOException ioex)
				{
					errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
							IOException.class.getName(), ioex.getMessage());
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
				}
	
				catch (Exception ex)
				{
					errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
							Exception.class.getName(), ex.getMessage());
					logger.error(errorMsg);
					returnValue = false;
	
					context.getMessages().add(
							new Message(MessageLevel.SEVERE, errorMsg));
				}
				
				finally
				{		
					boolean r2 = false;				
					r2 = this.close();
	
					returnValue = (( returnValue && r2 ) ? true : false);				
				}
	
			}

			// Safety Purposes
			keepOnTrucking = false;
			break;
			
		}
		
		logger.debug(BaseConstants.ENDS);

		return (returnValue);
	}

	private boolean decryptString()
	{
		boolean returnValue = false;
		String errorMsg = null;

		Log logger = methIDDecryptString;

		logger.debug(BaseConstants.BEGINS);

		// String to decrypt. It does not have to be a text file!

	
		logger.debug(BaseConstants.ENDS);
		
		return( returnValue );
	}
}
