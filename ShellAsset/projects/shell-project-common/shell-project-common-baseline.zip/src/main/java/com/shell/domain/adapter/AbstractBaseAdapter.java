package com.shell.domain.adapter;

import java.util.List;

import com.shell.domain.common.message.Message;

public abstract class AbstractBaseAdapter implements Adapter
{

	protected List messages = null;

	public List<Message> getMessages()
	{
		return messages;
	}

}
