/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */
package com.shell.domain.common.constant;

public final class ErrorMessageConstants
{

	public static final String ID_IS_NULL							= "ID is NULL!!!";
	
	public static final String PASSWORD_TOO_SHORT 					= "The Password Used is too short, minimum 8 characters.";
	public static final String BASE_IS_NULL							= "Base is NULL!";
	public static final String INTERNAL_ID_IS_NULL_EMPTY			= "Internal ID is NULL or Empty!!";
	public static final String CONTEXT_IS_NULL						= "Context is NULL!";
	public static final String CONTEXT_PARAMS_ARE_NULL				= "Context parameters ARE NULL!!!";
	public static final String PASSWORD_IS_NULL						= "Password is NULL!!!";
	public static final String PROPERTY_FILE_NOT_FOUND				= "%s Property File Not Found!!!";	
	public static final String PROPERTIES_FILE_NAME_IS_NULL			= "Properties FileName IS NULL!!!";	
	public static final String URL_LOCATION_IS_NULL					= "URL location to File is NULL!!!";
	public static final String XML_STRUCTURE_BAD					= "There is a problem with the structure of the xml document.  There should only be 1 \"root\" element beneath each region element.";	
	public static final String CANNOT_FIND_ELEMENT_IN_REGION		= "Unable to find element: |%s| Within region: |%s| For Environment: |%s|";
	public static final String CANNOT_GET_URL_FOR_FILENAME			= "Unable to get URL for FileName: |%s|";
	public static final String CLASSPATH_LOCATION_IS_NULL			= "ClassPath Location IS NULL!!!";
	public static final String UNABLE_TO_LOAD_CLASSPATH_RESOURCE 	= "Unable to Locate ClassPath Resource: %s";
	public static final String UNABLE_TO_DETERMINE_CURRENT_ENVIRO	= "Unable to determine the current environment!!!  Please make sure the property: |%s| is set in File: |%s|";
	public static final String UNABLE_TO_PARSE_FILE					= "Unable to parse properties file: |%s|";

	
	
	// Hide This!
	private ErrorMessageConstants()
	{		
	}
	
}
