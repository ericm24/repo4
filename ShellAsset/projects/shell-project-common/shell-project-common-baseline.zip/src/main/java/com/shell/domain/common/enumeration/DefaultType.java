/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */
package com.shell.domain.common.enumeration; 

import com.shell.command.AbstractBaseCommand;
import com.shell.command.Command;

/**
 *  Enum of Command Options for Command Structure. 
 * 
 * @author em32459 
 * 
 * @see Command
 * @see AbstractBaseCommand
 * 
 */
public enum DefaultType
{
	VER 			("51"),
	INSTANCE 		("1"),
	CLUSTER 		("APPS"),
	CLONE 			("1");
	
	private DefaultType(String newValue)
	{
		this.value = newValue;
	}
	
	private final String value;
	
	public String toString() 
	{
		return value;
	}		
};
