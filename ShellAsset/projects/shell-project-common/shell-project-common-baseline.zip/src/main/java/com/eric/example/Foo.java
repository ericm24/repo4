package com.eric.example;

import org.apache.log4j.Logger;

public class Foo
{

	private final static Logger methIDdoSomething;

	
	static
	{
		methIDdoSomething	 						= Logger.getLogger(Foo.class.getName() + ".doSomething()");		
	}
	
	public String doSomething()
	{
		Logger logger = methIDdoSomething;
		
		String returnValue = "Something2Return4You";		
		
		logger.debug("Begins...");
	
		logger.debug("Ends...");	
	
		return( returnValue );
	}
	

	
}