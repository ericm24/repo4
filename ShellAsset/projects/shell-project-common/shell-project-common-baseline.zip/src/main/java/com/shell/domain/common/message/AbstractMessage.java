/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */
package com.shell.domain.common.message;

import com.shell.domain.AbstractDomainBase;


public abstract class AbstractMessage<E extends Enum<E>> extends AbstractDomainBase
{
	private final E e;

	public AbstractMessage(E e)
	{
		this.e = e;
	}

	public E getLevel()
	{
		return (e);
	}

}
