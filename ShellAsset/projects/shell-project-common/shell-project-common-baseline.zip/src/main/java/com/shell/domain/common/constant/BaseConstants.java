/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */
package com.shell.domain.common.constant;

public final class BaseConstants
{
	public final static String PERF						= "PERF.";
	public final static String BEGINS 					= "Begins.....";
	public final static String ENDS 					= "Ends.....";
	public final static String FILE_IN 					= "FILE_IN";
	public final static String FILE_OUT 				= "FILE_OUT";
	public final static String PASSWORD 				= "PASSWORD";
	public final static String EXE_FILE 				= "ExeFile";
	public final static String BAT_FILE 				= "BatFile";
	public final static String BLANK_STRING				= "";
	public final static String SPACE					= " ";

	public final static String TARGET_FILE 				= "TargetFile";
	public final static String TARGET_RUN_FILE 			= "TargetRunFile";
	public final static String ONE 						= "1";
	public final static String TWO 						= "2";
	public final static String FIVE						= "5";	
	public final static String SIX						= "6";	
	public final static String SEVEN					= "7";	
	public static final String MINUS 					= "-";
	public static final String PLUS 					= "+";
	public static final String PIPE						= "|";
	public static final String PARAM_N 					= "Param.N";
	
	public static final int    MIN_PASSWORD_LENGTH		= 8;
	public static final int	   NO_BYTES_READ			= -1;
	public static final String FIVE_SPACES				= "     ";
	public static final String NULL_DELIMITED			= "|null| ";

	public static final String REGION_DEFAULT 			= "DEFAULT";
	public static final String DEFAULT_CONFIG_PATH		= "./config/";	
	public static final String PROPERTY_NAME_VALUE		= "Property Key: |%s| Value: |%s|";
	public static final String SETTING_ENVIRO_TO		= "Environment Key is NULL or EMPTY!! Setting region to: |%s|";
	
	// Hide This!
	private BaseConstants()
	{		
	}
	
}
