package com.shell.domain.adapter;

import java.util.List;

import com.shell.domain.common.message.Message;
import com.shell.domain.context.ShellContext;

public interface Adapter
{
	public List<Message> getMessages();

	public ShellContext toContext(String[] params);

}
