/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */ 
package com.shell.command;

import com.shell.domain.context.ShellContext;


/**
 * Command interface that follows GO4 Command Pattern.  .execute() & .undo()
 * are required behavior methods.
 * 
 * @author em32459
 * 
 */
public interface Command
{
	/**
     * Execute concrete behavior, main command method, to get-r-done!
     * @return <CODE>true</CODE> if command successful.  
     * 
     *  If false, check the message collection.
     * 
     * <CODE>false</CODE> otherwise
     */	
	public boolean execute();

	/**
     * UNDO changes by execute method.  Restores context and object-graph 
     * to original form.
     * @return <CODE>true</CODE> if UNDO successful. 
     * <CODE>false</CODE> otherwise
     */
	public boolean undo();

	/**
     * Required to add the context to the command instance.
     * @param ShellContext
     * 
     * @return <CODE>true</CODE> if UNDO successful. 
     * <CODE>false</CODE> otherwise
     */
	public void setContext(ShellContext context);
}
