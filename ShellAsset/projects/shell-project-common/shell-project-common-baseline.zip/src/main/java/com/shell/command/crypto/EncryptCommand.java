/**
 * ---------------------------------------------------------------------------
 * COPYRIGHT NOTICE  Copyright (c) 2011 by Citigroup, Inc.  All rights reserved.
 * These materials are confidential and proprietary to  Citigroup, Inc.
 * No part of this code may be reproduced, published in
 * any form by any means (electronic or mechanical, including photocopy or
 * any information storage or retrieval system), nor may the materials be
 * disclosed to third parties, or used in derivative works without the
 * express written authorization of Citigroup, Inc.
 * ---------------------------------------------------------------------------
 */
package com.shell.command.crypto;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.shell.domain.common.constant.BaseConstants;
import com.shell.domain.common.constant.CommandConstants;
import com.shell.domain.common.constant.CryptoConstants;
import com.shell.domain.common.constant.ErrorMessageConstants;
import com.shell.domain.common.enumeration.CommandOption;
import com.shell.domain.common.enumeration.MessageLevel;
import com.shell.domain.common.message.ExMessages;
import com.shell.domain.common.message.Message;


/**
 * Concrete Implementation for Command interface that performs Triple-Des encryption 
 * and follows GO4 Command Pattern.  .execute() & .undo() are required behavior methods.
 * 
 * @author em32459 
 * 
 * @see CommandOption
 * 
 */
public class EncryptCommand extends AbstractBaseCryptoCommand 
{
	/**
	 * Note: As with the pervious example, all kinds of exceptions can be thrown
	 * in main. See the API documentation for each method used.
	 */

	private static final Log methIDExecute; 
	private static final Log methIDEncryptFile;
	private static final Log methIDEncryptString;	
	private static final Log methIDExecuteP;
	
	static 
	{
		methIDExecute = LogFactory
			.getLog(EncryptCommand.class.getName() + ".execute()");
	
		methIDEncryptFile = LogFactory
			.getLog(EncryptCommand.class.getName() + ".encryptFile()");

		methIDEncryptString = LogFactory
			.getLog(EncryptCommand.class.getName() + ".encryptString()");
		
		methIDExecuteP = LogFactory
			.getLog("PERF." + EncryptCommand.class.getName() + ".execute()");
	}

	/**
     * Executes encryption algorythim on file specified in the context.
     * @return <CODE>true</CODE> if command successful.  
     * 
     *  If false, check the message collection.
     * 
     * <CODE>false</CODE> otherwise
     */
	@Override
	public boolean execute()
	{

		Log logger 	= methIDExecute;
		Log loggerP = methIDExecuteP;

		logger.debug( BaseConstants.BEGINS );
		loggerP.info( BaseConstants.BEGINS );		

		String errorMsg 				= null;
		CommandOption commandOption 	= null;
		
		boolean keepOnTrucking			= true;
		boolean returnValue 			= false;

		
		while ( keepOnTrucking )
		{
			if ( context == null )
			{
				errorMsg = CommandConstants.ERROR_MESSAGE_NULL_CONTEXT;
				logger.error( errorMsg );
				keepOnTrucking = false;
				
				break;			
			}

			commandOption = (CommandOption)context.getParams().get( CommandConstants.COMMAND_OPTION ); 
		
			if (  commandOption == null )
			{
				errorMsg = CommandConstants.ERROR_MESSAGE_NULL_CONTEXT;
				logger.error( errorMsg );
				keepOnTrucking = false;			
			}
			
			if ( commandOption.equals( CommandOption.FILE_ENCRYPT ))
			{
				returnValue = this.encryptFile();
			}
			else if ( commandOption.equals( CommandOption.STRING_ENCRYPT ))
 			{
				returnValue = this.encryptString();				
			}	
			else
			{
				errorMsg = String.format(CommandConstants.ERROR_INVALID_COMMAND_OPTION, 
						                 commandOption,
						                 EncryptCommand.class.getName());
				
				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
				
				logger.error( errorMsg );
				keepOnTrucking = false;				
			}
				
			// Safety Purposes.
			keepOnTrucking = false;
		}

		loggerP.info( BaseConstants.ENDS );
		logger.debug( BaseConstants.ENDS );

		
		return ( returnValue );
	}

	/**
     * UNDO changes by execute method.  Restores context and object-graph 
     * to original form, and in this case returns target string as it existed
     * before, (could be encrypted or decrypted).
     * @return <CODE>true</CODE> if UNDO successful. 
     * <CODE>false</CODE> otherwise
     */
	@Override
	public boolean undo()
	{

		boolean returnValue = false;

		return (returnValue);
	}

	private boolean encryptFile()
	{
		boolean returnValue 	= false;
		boolean keepOnTrucking 	= true;
		String errorMsg 		= null;

		Log logger = methIDEncryptFile;

		logger.debug(BaseConstants.BEGINS);

		// File to encrypt. It does not have to be a text file!

		while( keepOnTrucking )
		{
			if (context == null)
			{
				errorMsg = CommandConstants.ERROR_MESSAGE_NULL_CONTEXT;
				logger.error(errorMsg);
				
				keepOnTrucking = false;
				break;
			}
			// TODO: Add Call to Validator!
			
			this.setFileNameIn((String)context.getParams().get(BaseConstants.FILE_IN));			
			this.setPassword((String)context.getParams().get(BaseConstants.PASSWORD));				
			

			// Password must be at least 8 characters (bytes) long
			if ( this.getPassword().length() < BaseConstants.MIN_PASSWORD_LENGTH )			
			{				
				errorMsg = ErrorMessageConstants.PASSWORD_TOO_SHORT;				
				logger.error(errorMsg);			
				
				context.getMessages().add(
						new Message(MessageLevel.SEVERE, ErrorMessageConstants.PASSWORD_TOO_SHORT.toString()));
				keepOnTrucking = false;
				break;				
			}

			try
			{
				// Read it in.
				this.setInFile(new FileInputStream(this.getFileNameIn()));				
				this.setFileNameTemp(this.getFileNameIn() + ".des");				
				this.setOutFile(new FileOutputStream(this.getFileNameTemp()));

				// Use PBEKeySpec to create a key based on a password.
				// The password is passed as a character array

				PBEKeySpec keySpec = new PBEKeySpec(this.getPassword().toCharArray());					

				SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(CryptoConstants.PBEWITHMD5ANDDES);

				SecretKey passwordKey = keyFactory.generateSecret(keySpec);

				// PBE = hashing + symmetric encryption. A 64 bit random
				// number (the salt) is added to the password and hashed
				// using a Message Digest Algorithm (MD5 in this example.).
				// The number of times the password is hashed is determined
				// by the interation count. Adding a random number and
				// hashing multiple times enlarges the key space.

				byte[] salt = new byte[ CryptoConstants.SALT_SIZE ];
				Random rnd = new Random();
				rnd.nextBytes(salt);
				int iterations = 100;

				// Create the parameter spec for this salt and interation count

				PBEParameterSpec parameterSpec = new PBEParameterSpec(salt, iterations);

				// Create the cipher and initialize it for encryption.

				Cipher cipher = Cipher.getInstance(CryptoConstants.PBEWITHMD5ANDDES);
				
				cipher.init(Cipher.ENCRYPT_MODE, passwordKey, parameterSpec);

				// Need to write the salt to the (encrypted) file. The
				// salt is needed when reconstructing the key for decryption.

				this.getOutFile().write(salt);				

				// Read the file and encrypt its bytes.

				byte[] input = new byte[64];
				int bytesRead;
				
				for (bytesRead = this.getInFile().read(input); (bytesRead != BaseConstants.NO_BYTES_READ); )		
				{
					byte[] output = cipher.update(input, 0, bytesRead);
					if (output != null)
					{
						this.getOutFile().write(output);
					}
					bytesRead = this.getInFile().read(input);					
				}

				byte[] output = cipher.doFinal();
				if (output != null)
				{
					this.getOutFile().write(output);					
				}
				
				returnValue = true;				
			}
			
			/* Java7 
			catch ( NoSuchPaddingException | InvalidAlgorithmParameterException mEx )
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						NoSuchPaddingException.class.getName(), mEx
								.getMessage());
			}
			*/

			catch ( NoSuchPaddingException nspex )
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						NoSuchPaddingException.class.getName(), nspex
								.getMessage());

				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}
			catch (InvalidAlgorithmParameterException iapex)
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						InvalidAlgorithmParameterException.class.getName(),
						iapex.getMessage());
				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}

			catch (InvalidKeyException ikex)
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						InvalidKeyException.class.getName(), ikex.getMessage());
				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}

			catch (InvalidKeySpecException iksex)
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						InvalidKeySpecException.class.getName(), iksex
								.getMessage());
				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}

			catch (IllegalBlockSizeException ibsex)
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						IllegalBlockSizeException.class.getName(), ibsex
								.getMessage());
				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}

			catch (BadPaddingException bpex)
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						BadPaddingException.class.getName(), bpex.getMessage());
				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}

			catch (NoSuchAlgorithmException nsaex)
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						NoSuchAlgorithmException.class.getName(), nsaex
								.getMessage());
				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}

			catch (FileNotFoundException fnfex)
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						FileNotFoundException.class.getName(), fnfex
								.getMessage());
				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}

			catch (IOException ioex)
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						IOException.class.getName(), ioex.getMessage());
				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}

			catch (Exception ex)
			{
				errorMsg = String.format(ExMessages.GENEXCEPTION_ENCOUNTERED,
						Exception.class.getName(), ex.getMessage());
				logger.error(errorMsg);
				returnValue = false;

				context.getMessages().add(
						new Message(MessageLevel.SEVERE, errorMsg));
			}
			
			finally
			{				
				returnValue = this.close();				
			}
	
			// Safety Purposes
			keepOnTrucking = false;
			break;
			
		}	// End While

		logger.debug(BaseConstants.ENDS);

		return (returnValue);
	}
	
	private boolean encryptString()
	{
		boolean returnValue = true; 
		String errorMsg = null;

		Log logger = methIDEncryptString;

		logger.debug(BaseConstants.BEGINS);

		// String to encrypt. It does not have to be a text file!

		if (context == null)
		{
			errorMsg = CommandConstants.ERROR_MESSAGE_NULL_CONTEXT;
			logger.error(errorMsg);

		}
	
		
		return( returnValue );
	}
}
